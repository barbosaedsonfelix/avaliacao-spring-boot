# Avaliação Java SVA

## Tecnologias presentes na prova:  

* Spring Boot  
* Theme Leaf  
* Spring Data  
* BootStrap  

## Por onde começar

* Realize um fork do projeto no github na sua conta
* Clone o projeto em seu computador

## Como fazer

Leia a documentação disponível no documento AvaliacaoJava_SVA.docx.

## Método de entrega
* Coloque seu nome e outras informações que desejar no o arquivo candidato.txt
* Faça os seus commits e o push para o seu repositório.
* Envie o link do repositório para a pessoa que solicitou a realização do teste.
