create table estudante (  	id bigint not null auto_increment,     
							nome varchar(60) not null,     
							email varchar(255) not null,     
							telefone varchar(20) ,          
							primary key(id) );
                            
insert into estudante (nome, email, telefone) values (
'Xawoy',
'xawoy@tms.com.br ',
'7199871-7777'
);                            
insert into estudante (nome, email, telefone) values (
'Furae',
'furae@tms.com.br ',
'7199871-7778'
);
insert into estudante (nome, email, telefone) values (
'Fupuy',
'fupuy@tms.com.br ',
'7199871-7779'
);
insert into estudante (nome, email, telefone) values (
'Kuer',
'kuer@tms.com.br ',
'7199871-7780'
);
insert into estudante (nome, email, telefone) values (
'Blias',
'blias@tms.com.br ',
'7199871-7781'
);
commit;
													