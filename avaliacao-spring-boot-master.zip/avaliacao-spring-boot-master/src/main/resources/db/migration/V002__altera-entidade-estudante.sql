ALTER TABLE estudante
  ADD matricula bigint not null DEFAULT 0
    AFTER telefone;
    
ALTER TABLE estudante
  ADD curso varchar(20)
    AFTER matricula;