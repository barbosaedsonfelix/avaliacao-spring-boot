package br.com.tokiomarine.seguradora.avaliacao.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.tokiomarine.seguradora.avaliacao.entidade.Estudante;
import br.com.tokiomarine.seguradora.avaliacao.repository.EstudanteRepository;



// TODO Efetue a implementação dos métodos da classe service
@Service
public class EstudanteRestService{

	@Autowired
	private EstudanteRepository estudanteRepository;
	
	
	public List<Estudante> buscarEstudantes() {
		
		return estudanteRepository.findAll();
	}
	
	public Optional<Estudante> buscarEstudante(Long estudanteId) {		
		return estudanteRepository.findById(estudanteId);		
	}	
	
	public Estudante cadastrarEstudante(Estudante estudante) {		
		return estudanteRepository.save(estudante);		
	}
	
	public void excluir(Long estudanteId) {
		estudanteRepository.deleteById(estudanteId);
	}	
}
