package br.com.tokiomarine.seguradora.avaliacao.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import br.com.tokiomarine.seguradora.avaliacao.entidade.Estudante;
import br.com.tokiomarine.seguradora.avaliacao.repository.EstudanteRepository;
import br.com.tokiomarine.seguradora.avaliacao.service.EstudanteRestService;


// TODO não esquecer de usar as anotações para criação do restcontroller

@RestController
@RequestMapping("/estudantes_rest/")
public class EstudanteRestController {
	
    @Autowired 
	private EstudanteRestService estudanteRestService;
     
     @Autowired
 	private EstudanteRepository repositoryEstudante;
	// TODO caso você não conheça THEMELEAF faça a implementação dos métodos em forma de RESTCONTROLLER (seguindo o padrão RESTFUL)

	// TODO IMPLEMENTAR CADASTRO DE ESTUDANTES (POST)

	// TODO IMPLEMENTAR ATUALIZACAO DE ESTUDANTES (PUT)

	// TODO IMPLEMENTAR A LISTAGEM DE ESTUDANTES (GET)
 	
     @GetMapping
 	public List<Estudante> listarEstudantes() {
    	 
 		return estudanteRestService.buscarEstudantes();
 	}
    
     /**
      * Coloquei pra retornar o status 404, caso não ache o estudante
      * @param estudanteId
      * @return
      */
 	@GetMapping("/{estudanteId}")
 	public ResponseEntity<Estudante> buscar(@PathVariable Long estudanteId) {
 		Optional<Estudante> estudante = estudanteRestService.buscarEstudante(estudanteId);

 		if (estudante.isPresent()) {
 			return ResponseEntity.ok(estudante.get());
 		}
 		return ResponseEntity.notFound().build();
 	}  
 	
	@PostMapping
	@ResponseStatus(HttpStatus.CREATED)
	public Estudante adicionar(@Valid @RequestBody Estudante estudante) {
		
		return estudanteRestService.cadastrarEstudante(estudante);
	} 
	
	@PutMapping("/{estudanteId}")
	public ResponseEntity<Estudante> atualizar ( @PathVariable Long estudanteId, @Valid @RequestBody Estudante estudante) {
			
		if (!repositoryEstudante.existsById(estudanteId)) {
			return ResponseEntity.notFound().build();
		}
		
		estudante.setId(estudanteId);
		estudanteRestService.cadastrarEstudante(estudante);;
		return ResponseEntity.ok(estudante);
	}	
	
	@DeleteMapping("/{estudanteId}")
	public ResponseEntity<Void> remover(@PathVariable Long estudanteId) {
		
		if (!repositoryEstudante.existsById(estudanteId)) {
			return ResponseEntity.notFound().build();
		}
		estudanteRestService.excluir(estudanteId);
		
		return ResponseEntity.noContent().build();
	}
		
     

	// TODO IMPLEMENTAR A EXCLUSÃO DE ESTUDANTES (DELETE)
}
